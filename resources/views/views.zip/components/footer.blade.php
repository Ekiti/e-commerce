<footer class="flex column middle no-wrap col-lg-6">
    <ul class="flex col-lg-5 center footer-ul flex-wrap">
        <li class="flex column no-wrap">
                <p> <b>Quick links</b> </p>
                <a href="#">Sell</a>
                <a href="#">Buy shoes</a>
                <a href="#">Women collections</a>
                <a href="#">Men collection</a>
                <a href="{{route('user.orders')}}">Orders</a>
                <a href="#">Report</a>
                <a href="{{ route('logout') }}"
                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                    {{ __('Logout') }}
                </a>

                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
        </li>
        <li class="flex column no-wrap">
                <p> <b>Legal</b> </p>
                <a href="#">Privacy policy</a>
                <a href="#">terms of use</a>
                <a href="#">Disclaimers</a>
                <a href="#">Return Policy</a>
                <a href="#">Cash back</a>
        </li>
        <li class="flex column no-wrap">
                <p> <b>Help & Contact</b> </p>
                <a href="{{ route('content.contact') }}">Contact us</a>
                <a href="#">Seller information center</a>
                <a href="#">Faqs</a>
                <a href="#">Payments</a>
                <a href="{{ route('content.about') }}">About</a>
        </li>
    </ul>
    <div class="flex col-lg-6 center middle wrap copyright flex-wrap">
        <p>&copy; {{date('Y')}} {{$settings->name}} All rights Reserved. |</p>
        <p> Powered by LightsUp Energy</p>
    </div>
</footer>