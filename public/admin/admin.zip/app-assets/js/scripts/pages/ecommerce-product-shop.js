// Product sidebar list scrollbarb
$(".sidebar-list").perfectScrollbar();
$(".product-cat").perfectScrollbar();